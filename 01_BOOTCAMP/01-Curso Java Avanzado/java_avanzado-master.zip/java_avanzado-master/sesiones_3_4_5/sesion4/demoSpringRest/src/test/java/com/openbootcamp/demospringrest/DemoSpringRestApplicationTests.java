package com.openbootcamp.demospringrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringRestApplicationTests {

    @Test
    void contextLoads() {
    }

}
