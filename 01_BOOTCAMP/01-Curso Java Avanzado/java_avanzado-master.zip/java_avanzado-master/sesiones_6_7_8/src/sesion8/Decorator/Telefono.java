package sesion8.Decorator;

public interface Telefono {
    void crear();
}
