// Creditos: https://refactoring.guru/es/design-patterns/facade/java/example#example-0

package sesion8.Facade;

public class MPEG4CompressionCodec implements Codec {
    public String type = "mp4";
}