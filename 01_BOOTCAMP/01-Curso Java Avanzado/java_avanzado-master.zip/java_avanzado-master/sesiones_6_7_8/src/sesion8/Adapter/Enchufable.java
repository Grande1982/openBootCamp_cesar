package sesion8.Adapter;

interface Enchufable {
    void enciende();
    void apaga();
    boolean tieneCorriente();
}
