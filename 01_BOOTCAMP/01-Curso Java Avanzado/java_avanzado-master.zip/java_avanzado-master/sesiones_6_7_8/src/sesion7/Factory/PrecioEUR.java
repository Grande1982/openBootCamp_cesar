package sesion7.Factory;

class PrecioEUR implements Precio {
    public double getPrecio() {
        return 1.3;
    }
}
