package sesion7.Factory;

class PrecioUSD implements Precio {
    public double getPrecio() {
        return 0.94;
    }
}
