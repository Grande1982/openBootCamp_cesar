package sesion7.Factory;

interface Precio {
    double getPrecio();
}
