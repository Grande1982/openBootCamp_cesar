package Sesion18.SRP;

public class Email {
    public void Enviar(String usuario) {}
}
