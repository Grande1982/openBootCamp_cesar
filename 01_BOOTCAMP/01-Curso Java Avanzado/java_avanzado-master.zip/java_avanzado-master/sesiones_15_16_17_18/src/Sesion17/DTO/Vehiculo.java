package Sesion17.DTO;

import java.util.ArrayList;

public class Vehiculo {
    String nombre;

    public Vehiculo(String nombre) {
        this.nombre = nombre;
    }
}
