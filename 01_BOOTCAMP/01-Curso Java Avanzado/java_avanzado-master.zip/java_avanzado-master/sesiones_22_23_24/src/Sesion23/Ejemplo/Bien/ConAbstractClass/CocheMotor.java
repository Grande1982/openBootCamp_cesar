package Sesion23.Ejemplo.Bien.ConAbstractClass;

public class CocheMotor extends Vehiculo {
    public CocheMotor() {
        super("Motor");
    }
}
