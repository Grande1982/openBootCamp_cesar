package Sesion23.Ejemplo.Mal;

public class Main {
    public static void main(String []args) {
        Vehiculo vehiculo = new Vehiculo("Coche");
    }
}
