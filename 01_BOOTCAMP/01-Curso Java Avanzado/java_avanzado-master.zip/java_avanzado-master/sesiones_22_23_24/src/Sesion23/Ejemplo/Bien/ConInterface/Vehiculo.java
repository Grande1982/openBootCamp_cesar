package Sesion23.Ejemplo.Bien.ConInterface;

interface Vehiculo {
    String getTipoVehiculo();
}
