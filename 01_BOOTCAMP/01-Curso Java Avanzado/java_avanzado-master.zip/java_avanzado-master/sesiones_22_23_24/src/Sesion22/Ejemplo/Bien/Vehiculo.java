package Sesion22.Ejemplo.Bien;

import java.lang.reflect.Array;
import java.util.ArrayList;

class Vehiculo {
    String tipo;

    public Vehiculo(String tipo) {
        this.tipo = tipo;
    }

    public String getTipoVehiculo() {
        return tipo;
    }
}
