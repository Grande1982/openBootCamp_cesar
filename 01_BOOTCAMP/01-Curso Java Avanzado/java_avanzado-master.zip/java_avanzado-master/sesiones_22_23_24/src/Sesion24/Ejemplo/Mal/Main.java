package Sesion24.Ejemplo.Mal;

public class Main {
    public static void main(String []args) {
        Aritmetica ari = new Aritmetica();
        ari.suma(2, 2);

        AritmeticaMejorada arimejor = new AritmeticaMejorada();
        arimejor.suma(2, 2);
    }
}
