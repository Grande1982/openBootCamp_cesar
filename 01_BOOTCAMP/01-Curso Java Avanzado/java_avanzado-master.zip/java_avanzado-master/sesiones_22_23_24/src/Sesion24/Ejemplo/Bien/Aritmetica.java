package Sesion24.Ejemplo.Bien;

abstract class Aritmetica {
    abstract int suma(int A, int B);
    abstract int multiplicacion(int A, int B);
    abstract int resta(int A, int B);
    abstract int division(int A, int B);
}
