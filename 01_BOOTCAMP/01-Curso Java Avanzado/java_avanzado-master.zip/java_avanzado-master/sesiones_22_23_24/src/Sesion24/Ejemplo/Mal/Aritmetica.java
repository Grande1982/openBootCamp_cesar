package Sesion24.Ejemplo.Mal;

public class Aritmetica {
    public int suma(int A, int B) {
        return A + B;
    }

    public int multiplicacion(int A, int B) {
        return A * B;
    }
}
