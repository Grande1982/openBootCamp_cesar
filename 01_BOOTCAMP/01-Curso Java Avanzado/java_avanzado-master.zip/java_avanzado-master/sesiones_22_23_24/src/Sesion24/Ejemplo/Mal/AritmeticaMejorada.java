package Sesion24.Ejemplo.Mal;

public class AritmeticaMejorada {
    public int suma(int A, int B) {
        return A + B;
    }

    public int multiplicacion(int A, int B) {
        return A * B;
    }

    public int resta(int A, int B) {
        return A - B;
    }

    public int division(int A, int B) {
        return A / B;
    }
}
