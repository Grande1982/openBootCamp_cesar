package Sesion20.O;

    class Usuario {
        String username;

        Usuario(String username){ this.username = username; }

        String getMarcaUsuario(){ return username; }
    }


